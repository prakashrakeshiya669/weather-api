from django.http import HttpResponse
from django.shortcuts import render,redirect
from . import models
from . import emailAPI
import time
# create Views Here
def home(request):
    return render(request, 'home.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def service(request):
    return render(request, 'service.html')

def register(request):
    if request.method=="GET":
        return render(request, 'register.html',{"output":""})
    else:
        #to recive data from UI
        name=request.POST.get("name")
        email=request.POST.get("email")
        password=request.POST.get("password")
        mobile=request.POST.get("mobile")
        

        #to send verification email
        emailAPI.sendMail(email,password)

        #insert record in data base table
        r=models.Register(name=name, email=email, password=password, mobile=mobile,status=0,role="user",info=time.asctime())
        r.save()
        
        return render(request, 'register.html',{"output": "User Register Successfull.........!"})


def vemail(request):
    if request.method=="GET":
     return render(request, 'vemail.html')
    else:
        email=request.POST.get("email")
        ems=models.Register.objects.filter(email=email)
        
def verify(request):
    vemail=request.GET.get("vemail")
    #print(vemail)
    #return HttpResponse("This is Verify email")
    models.Register.objects.filter(email=vemail).update(status=1)
    
    return redirect("/login/")

def login(request):
    if request.method=="GET":
     return render(request, 'login.html', {"output":" "})
    else:
      email=request.POST.get("email")
      password=request.POST.get("password")
      #print(chk)
      userDetails=models.Register.objects.filter(email=email,password=password,status=1)

      if len(userDetails)>0:
        print(userDetails[0].role)
        if userDetails[0].role=="admin":
           return render(request, 'login.html', {"output":" login Success as Admin"})
        else:
         return redirect('/user/')
      else:
        return render(request, 'login.html', {"output":"Invalid User or Verify Your Account"})
